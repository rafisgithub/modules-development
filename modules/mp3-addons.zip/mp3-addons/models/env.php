<?php

// $sql = "SELECT access_key, secret_key FROM tbloptions";
// $query = $this->db->query($sql);

// foreach ($query->result() as $row) {
//     // Process each row
// }



function givemekey(){

    $key = "AKIA5DH537WZNKAUUKYP";
    
    return $key;
}


function givemesecret(){

    $secret = "0TM70mPWsBNZClNwCqqxZl7nxGRQ68h7rxyrFFnI";

    return $secret;
}
