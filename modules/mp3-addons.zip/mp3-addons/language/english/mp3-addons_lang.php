<?php
$lang['mp3_addons'] = 'MP3-Addons';
$lang['mp3_addons_credential_setup'] = 'Set up credential for mp3-addons';
$lang['bucket_name'] = 'Bucket Name';
$lang['folder_name'] = 'Folder Name';
$lang['region_name'] = 'Region';
$lang['access_key'] = 'Access Key';
$lang['secret_key'] = 'Secret Key';
$lang['lead_name'] = 'Lead Name';
$lang['date'] = 'Date';
$lang['lead_id'] = 'Lead ID';
$lang['recording'] = 'Recording';

?>